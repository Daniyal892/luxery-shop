VELOURA PERFUME SHOP WEBSITE

Pages:
- index.html       Home
- shop.html        Product listing, sorting, add to bag
- collections.html Floral, Woody and Fresh collections
- about.html       Brand story
- contact.html     Contact form demo
- cart.html        Shopping bag with quantity controls

Technology:
HTML5, CSS3, JavaScript, Bootstrap 5.3.8, Bootstrap Icons.
Cart uses browser LocalStorage.

HOW TO RUN IN VS CODE:
1. Extract the ZIP file.
2. Open the extracted 'veloura-perfume-shop' folder in Visual Studio Code.
3. Install the Live Server extension (if it is not installed).
4. Right-click index.html and choose 'Open with Live Server'.
5. Use the navigation menu to visit the other pages.

IMPORTANT:
- Internet is needed for Bootstrap, Google Fonts and the sample Unsplash photos.
- Product names, prices, photos and contact details are demo content. Replace them with your own.
- Cart and checkout are frontend demonstrations only. Real payments, order processing and email delivery need a backend and a payment provider.
